/*
 * CO4: Multi-Framework Backend Engineering
 *
 * This is a SEPARATE service from the FastAPI backend, written in
 * Node.js/Express instead of Python. It connects to the SAME MySQL
 * database, proving that different services (in different languages)
 * can talk to shared data -- the core idea behind a polyglot,
 * multi-framework backend.
 *
 * Run with: npm start
 */

require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
app.use(cors());

const PORT = process.env.PORT || 3000;

// One shared connection pool, reused across requests
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

// Quick check that the server is alive
app.get('/health', (req, res) => {
  res.json({ message: 'Notification service is running', service: 'Node.js/Express' });
});

// The actual feature: which products are below their reorder level,
// across all warehouses -- presented as "notifications" a warehouse
// manager would want to see.
app.get('/notifications/low-stock', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT p.product_name, w.warehouse_name, i.quantity, p.reorder_level
      FROM inventory i
      JOIN products p ON p.product_id = i.product_id
      JOIN warehouses w ON w.warehouse_id = i.warehouse_id
      WHERE i.quantity < p.reorder_level
    `);

    const notifications = rows.map(row => ({
      message: `${row.product_name} is low in ${row.warehouse_name}: ${row.quantity} left (reorder at ${row.reorder_level})`,
      product_name: row.product_name,
      warehouse_name: row.warehouse_name,
      quantity: row.quantity,
      reorder_level: row.reorder_level,
    }));

    res.json({ count: notifications.length, notifications });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch low-stock notifications' });
  }
});

app.listen(PORT, () => {
  console.log(`Notification service (Node.js/Express) running on http://127.0.0.1:${PORT}`);
});
