"""
Everything related to login and security lives here.

The flow:
1. User sends username+password to /login
2. We check it against the `users` table (password is hashed, never plain text)
3. If correct, we hand back a JWT -- a signed, tamper-proof token
4. On every future request, the user sends that token instead of
   their password, and we verify it before allowing access
"""

import os
from datetime import datetime, timedelta
from dotenv import load_dotenv
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from database import get_db
from models import User

load_dotenv()

# In a real deployment this comes from .env, never hardcoded --
# for now, a placeholder is fine for a course project.
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "change-this-to-something-random-later")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Tells FastAPI: "tokens are obtained by POSTing to /login"
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")


def hash_password(plain_password: str) -> str:
    """Turn a plain password into a secure hash, for storing in the DB."""
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Check a login attempt's password against the stored hash."""
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: dict) -> str:
    """Build a signed JWT containing the given data (e.g. username, role)."""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """
    Runs automatically on any route that depends on it.
    Decodes the token from the request, checks it's valid and not
    expired, then loads the matching user from the database.
    """
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_error
    except JWTError:
        raise credentials_error

    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise credentials_error
    return user


def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """
    Use this instead of get_current_user on routes that should be
    ADMIN-only (e.g. creating/deleting products). Staff get a clean
    403 error instead of being allowed through.
    """
    if current_user.role != "ADMIN":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This action requires ADMIN role"
        )
    return current_user
