"""
This file sets up the connection to your MySQL database.
Nothing here changes your schema -- it just lets Python talk to
the tables you already created in Workbench.
"""

import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Load DATABASE_URL from the .env file (copy .env.example to .env
# and put your real MySQL password in it)
load_dotenv()
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "mysql+pymysql://root:yourpassword@127.0.0.1:3306/iwms"
)

# The "engine" is the actual connection to MySQL
engine = create_engine(DATABASE_URL)

# Each request gets its own short-lived "session" (like one conversation
# with the database) -- this factory creates those sessions
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# All our table models (in models.py) will inherit from this
Base = declarative_base()


def get_db():
    """
    FastAPI calls this for every request that needs the database.
    It hands over a session, then always closes it afterwards --
    even if the request crashed -- so connections don't pile up.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
