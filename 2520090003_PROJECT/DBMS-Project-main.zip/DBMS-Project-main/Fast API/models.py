"""
Each class here maps to one table you already created with schema_v2.sql.
We're starting with just Product -- we'll add Warehouse, Order, etc.
as we build out more endpoints.
"""

from sqlalchemy import Column, Integer, String, DECIMAL, DateTime
from database import Base


class Product(Base):
    __tablename__ = "products"

    product_id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String(150))
    category_id = Column(Integer)
    unit_price = Column(DECIMAL(10, 2))
    reorder_level = Column(Integer)

class Warehouse(Base):
    __tablename__ = "warehouses"

    warehouse_id = Column(Integer, primary_key=True, index=True)
    warehouse_name = Column(String(100))
    location = Column(String(150))
    address = Column(String(255))

class Inventory(Base):
    __tablename__ = "inventory"

    inventory_id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer)
    warehouse_id = Column(Integer)
    quantity = Column(Integer)

class Order(Base):
    __tablename__ = "orders"

    order_id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer)
    order_date = Column(DateTime)
    total_amount = Column(DECIMAL(10, 2))
    status = Column(String(20))

class User(Base):
    __tablename__ = "users"

    user_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150))
    username = Column(String(50))
    password = Column(String(255))
    role = Column(String(20))