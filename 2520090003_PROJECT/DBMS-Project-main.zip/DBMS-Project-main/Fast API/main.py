"""
This is the entry point of the API. Run it with:
    uvicorn main:app

Then open http://127.0.0.1:8000/docs in your browser --
FastAPI builds an interactive test page for you automatically.
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
import requests
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from database import get_db
from models import Product, Warehouse, Inventory, Order, User
from schemas import ProductCreate
from auth import hash_password, verify_password, create_access_token, get_current_user, require_admin

app = FastAPI(title="IWMS API")
import os
NOTIFICATION_SERVICE_URL = os.getenv("NOTIFICATION_SERVICE_URL", "http://127.0.0.1:3000")

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # allow requests from any origin -- fine for a local demo
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    """Quick check that the server is alive."""
    return {"message": "IWMS API is running"}


@app.get("/products")
def get_products(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Return every product currently in the database. Login required."""
    products = db.query(Product).all()
    return products


@app.post("/products")
def create_product(
    product: ProductCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Create a new product and save it to the database. ADMIN only."""
    new_product = Product(
        product_name=product.product_name,
        category_id=product.category_id,
        unit_price=product.unit_price,
        reorder_level=product.reorder_level
    )
    db.add(new_product)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Category does not exist")
    db.refresh(new_product)
    return new_product


@app.delete("/products/{product_id}")
def delete_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """Delete a product. ADMIN only."""
    product = db.query(Product).filter(Product.product_id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    try:
        db.delete(product)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="Product is used by other records (stock or orders) and can't be deleted",
        )
    return {"message": "Product deleted"}


@app.get("/warehouses")
def get_warehouses(db: Session = Depends(get_db)):
    """Return every warehouse currently in the database."""
    warehouses = db.query(Warehouse).all()
    return warehouses


@app.get("/inventory")
def get_inventory(db: Session = Depends(get_db)):
    """Return current stock levels across all warehouses."""
    inventory = db.query(Inventory).all()
    return inventory


@app.get("/orders")
def get_orders(db: Session = Depends(get_db)):
    """Return every order currently in the database."""
    orders = db.query(Order).all()
    return orders


@app.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Check username/password, return a JWT token if correct."""
    user = db.query(User).filter(User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, user.password):
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    token = create_access_token(data={"sub": user.username, "role": user.role})
    return {"access_token": token, "token_type": "bearer"}

@app.get("/gateway/low-stock-alerts")
def gateway_low_stock_alerts():
    """
    API Gateway route (CO5 demo).
    This route forwards the request to the Node.js microservice
    (notification-service) and returns its response through FastAPI.
    """
    try:
        response = requests.get(f"{NOTIFICATION_SERVICE_URL}/notifications/low-stock", timeout=5)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=502,
            detail=f"Could not reach notification-service (is it running on port 3000?): {e}"
        )

    return {
        "source_service": "notification-service (Node.js, port 3000)",
        "routed_through": "FastAPI gateway (port 8000)",
        "data": response.json()
    }

@app.get("/products/similar/{product_id}")
def get_similar_products(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Find products with similar names using TF-IDF + cosine similarity.
    This is CO2's vector-search feature: product names are turned into
    numeric vectors, and we find the closest ones by angle between vectors.
    Login required.
    """
    all_products = db.query(Product).all()

    if len(all_products) < 2:
        return {"message": "Not enough products to compare"}

    names = [p.product_name for p in all_products]
    ids = [p.product_id for p in all_products]

    # Turn product names into numeric vectors based on word frequency
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(names)

    # Find which row in our list is the product we're comparing against
    try:
        target_index = ids.index(product_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Product not found")

    # Compare that product's vector against every other product's vector
    similarity_scores = cosine_similarity(
        tfidf_matrix[target_index], tfidf_matrix
    ).flatten()

    # Pair each product with its similarity score, sort highest first,
    # skip the product itself, take the top 3
    scored = list(zip(ids, names, similarity_scores))
    scored.sort(key=lambda x: x[2], reverse=True)
    top_matches = [s for s in scored if s[0] != product_id][:3]

    return [
        {"product_id": pid, "product_name": name, "similarity_score": round(float(score), 3)}
        for pid, name, score in top_matches
    ]