"""
Pydantic schemas define the SHAPE of data coming IN and going OUT
of the API -- separate from SQLAlchemy models, which define the
shape of data in the DATABASE. FastAPI uses these to automatically
validate requests and reject bad data before it ever reaches MySQL.
"""

from pydantic import BaseModel


class ProductCreate(BaseModel):
    """
    What the CLIENT must send us to create a new product.
    No product_id here -- MySQL generates that automatically
    (AUTO_INCREMENT), so the client never provides it.
    """
    product_name: str
    category_id: int
    unit_price: float
    reorder_level: int = 10   # optional -- defaults to 10 if not sent
