# Inventory & Warehouse Management System (IWMS)

A full-stack backend project that manages products, warehouses, stock, and
customer orders across multiple locations — combining a relational MySQL
core, a lightweight product-similarity search, two independent backend
services connected through an API gateway, and Docker-based deployment.

Built for **Database Systems Engineering and Distributed Backend
Development** (CO1–CO6).

---

## What's inside

| Course Outcome | What it demonstrates | Where |
|---|---|---|
| CO1 | Relational database design — 11 tables, triggers, stored procedures, views | `mysql-init/01-schema.sql` |
| CO2 | Product similarity search (NoSQL/vector-DB alternative) via TF-IDF + cosine similarity | `Fast API/main.py` |
| CO3 | Secure REST API — JWT auth, role-based access control | `Fast API/` (FastAPI) |
| CO4 | Second backend service in a different framework | `notification-service/` (Node.js/Express) |
| CO5 | API Gateway pattern connecting the two services | `GET /gateway/low-stock-alerts` in `Fast API/main.py` |
| CO6 | Containerized deployment | `docker-compose.yml` + 2 Dockerfiles |

---

## Tech stack

- **Database:** MySQL 8.0
- **Primary backend:** FastAPI + SQLAlchemy + PyMySQL (Python)
- **Secondary backend:** Node.js + Express + mysql2 (JavaScript)
- **Auth:** JWT (python-jose) + bcrypt password hashing
- **Similarity engine:** scikit-learn (TF-IDF + cosine similarity)
- **Frontend:** plain HTML/CSS/JavaScript dashboard
- **Deployment:** Docker + Docker Compose

---

## Project structure

```
DBMS project/
├── docker-compose.yml
├── dashboard.html              ← open this in a browser to use the app
├── mysql-init/
│   └── 01-schema.sql           ← auto-loaded into MySQL on first container start
├── Fast API/                   ← primary backend (FastAPI)
│   ├── Dockerfile
│   ├── main.py
│   ├── models.py
│   ├── database.py
│   ├── schemas.py
│   ├── auth.py
│   └── requirements.txt
└── notification-service/       ← secondary backend (Node.js)
    ├── Dockerfile
    ├── server.js
    └── package.json
```

---

## Running it (Docker — recommended)

Requires [Docker Desktop](https://www.docker.com/products/docker-desktop/).

```bash
cd "DBMS project"
docker-compose up -d
```

This starts three containers: MySQL (auto-loaded with the schema and sample
data), the FastAPI service, and the Node.js service.

Check everything is running:

```bash
docker-compose ps
```

Then open `dashboard.html` in a browser and log in:

- **Username:** `admin`
- **Password:** `admin123`

Or explore the API directly at `http://127.0.0.1:8000/docs`.

To stop everything:

```bash
docker-compose down
```

---

## Running it locally (without Docker)

**FastAPI backend:**
```bash
cd "Fast API"
python -m venv venv
venv\Scripts\Activate.ps1        # Windows PowerShell
pip install -r requirements.txt
uvicorn main:app
```

**Node.js service** (in a separate terminal):
```bash
cd notification-service
npm install
npm start
```

Both must be running at the same time — FastAPI on port 8000, Node.js on
port 3000 — for the dashboard to work fully. MySQL must also be running
locally on port 3306 with the schema from `mysql-init/01-schema.sql` loaded.

---

## API endpoints (FastAPI, port 8000)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/login` | Authenticate and receive a JWT token |
| GET | `/products` | List all products |
| POST | `/products` | Add a product (Admin only) |
| DELETE | `/products/{product_id}` | Delete a product (Admin only) |
| GET | `/products/similar/{product_id}` | Top 3 similar products (TF-IDF + cosine similarity) |
| GET | `/warehouses` | List all warehouses |
| GET | `/inventory` | List stock by warehouse |
| GET | `/orders` | List all orders |
| GET | `/gateway/low-stock-alerts` | Gateway route — forwards to the Node.js service |

## API endpoints (Node.js, port 3000)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Liveness check |
| GET | `/notifications/low-stock` | List products below their reorder level |

---

## Database schema (CO1)

- **11 tables:** users, categories, suppliers, warehouses, customers,
  products, inventory, stock_in, stock_out, orders, order_details
- **2 triggers:** auto-sync inventory on stock-in / stock-out
- **2 stored procedures:** `sp_record_stock_in`, `sp_record_stock_out`
  (raise an error on insufficient stock)
- **5 views:** stock summary, low-stock report, warehouse-wise stock,
  order report, sales report

---

## Known simplifications

These were deliberate scope decisions for a short academic timeline —
listed here rather than hidden:

- TF-IDF + cosine similarity stands in for a real vector database
  (pgvector/FAISS) — see Future Work.
- All services share one MySQL database rather than a database-per-service
  model with Saga/2PC transactions.
- No Kubernetes, Prometheus, or CI/CD — Docker Compose only.

## Future work

- Swap the TF-IDF similarity engine for a real vector database.
- Move to database-per-service with proper distributed transactions.
- Add structured logging, metrics, and dashboards (Prometheus/Grafana).
- Orchestrate with Kubernetes; add CI/CD.

---

## Team

- D. Sri Varshini — 2520080013
- S. Vennela — 2520080018
- S. Udaya Sri — 2520090003

**Guide:** Dr. M. Gayatri, Associate Professor
