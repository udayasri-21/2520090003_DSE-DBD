-- ============================================================
-- Inventory & Warehouse Management System (IWMS)
-- Matches the System Architecture diagram (Data Layer)
-- Target: MySQL 8.0+
-- ============================================================

CREATE DATABASE IF NOT EXISTS iwms;
USE iwms;

-- ------------------------------------------------------------
-- 1. Users (login / RBAC — Admin or Warehouse Staff)
-- ------------------------------------------------------------

CREATE TABLE users (
    user_id         INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    username        VARCHAR(50) NOT NULL UNIQUE,
    password        VARCHAR(255) NOT NULL,   -- store a bcrypt hash, never plain text
    role            ENUM('ADMIN', 'STAFF') NOT NULL DEFAULT 'STAFF'
);

-- ------------------------------------------------------------
-- 2. Lookup tables
-- ------------------------------------------------------------

CREATE TABLE categories (
    category_id     INT AUTO_INCREMENT PRIMARY KEY,
    category_name   VARCHAR(100) NOT NULL UNIQUE,
    description     VARCHAR(255)
);

CREATE TABLE suppliers (
    supplier_id     INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name   VARCHAR(150) NOT NULL,
    contact_no      VARCHAR(20),
    email           VARCHAR(150) NOT NULL UNIQUE,
    address         VARCHAR(255)
);

CREATE TABLE warehouses (
    warehouse_id    INT AUTO_INCREMENT PRIMARY KEY,
    warehouse_name  VARCHAR(100) NOT NULL,
    location        VARCHAR(150) NOT NULL,
    address         VARCHAR(255)
);

CREATE TABLE customers (
    customer_id     INT AUTO_INCREMENT PRIMARY KEY,
    customer_name   VARCHAR(150) NOT NULL,
    contact_no      VARCHAR(20),
    email           VARCHAR(150) NOT NULL UNIQUE,
    address         VARCHAR(255)
);

-- ------------------------------------------------------------
-- 3. Products & Inventory
-- ------------------------------------------------------------

CREATE TABLE products (
    product_id      INT AUTO_INCREMENT PRIMARY KEY,
    product_name    VARCHAR(150) NOT NULL,
    category_id     INT NOT NULL,
    unit_price      DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
    reorder_level   INT NOT NULL DEFAULT 10 CHECK (reorder_level >= 0),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

CREATE INDEX idx_products_category ON products(category_id);

CREATE TABLE inventory (
    inventory_id    INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NOT NULL,
    warehouse_id    INT NOT NULL,
    quantity        INT NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    UNIQUE (product_id, warehouse_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id) ON DELETE CASCADE
);

CREATE INDEX idx_inventory_warehouse ON inventory(warehouse_id);

-- ------------------------------------------------------------
-- 4. Stock movement — separate IN / OUT tables, as in the diagram
-- ------------------------------------------------------------

CREATE TABLE stock_in (
    stockin_id      INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NOT NULL,
    warehouse_id    INT NOT NULL,
    supplier_id     INT NOT NULL,
    quantity        INT NOT NULL CHECK (quantity > 0),
    date            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
);

CREATE TABLE stock_out (
    stockout_id     INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NOT NULL,
    warehouse_id    INT NOT NULL,
    quantity        INT NOT NULL CHECK (quantity > 0),
    date            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reference_type  VARCHAR(50),   -- e.g. 'ORDER', 'DAMAGE', 'TRANSFER'
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
);

CREATE INDEX idx_stockin_product_wh ON stock_in(product_id, warehouse_id);
CREATE INDEX idx_stockout_product_wh ON stock_out(product_id, warehouse_id);

-- ------------------------------------------------------------
-- 5. Orders
-- ------------------------------------------------------------

CREATE TABLE orders (
    order_id        INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT NOT NULL,
    order_date      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount    DECIMAL(10,2) DEFAULT 0.00,
    status          ENUM('PENDING', 'CONFIRMED', 'SHIPPED', 'CANCELLED') NOT NULL DEFAULT 'PENDING',
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_details (
    order_detail_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id        INT NOT NULL,
    product_id      INT NOT NULL,
    quantity        INT NOT NULL CHECK (quantity > 0),
    unit_price      DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE INDEX idx_orderdetails_order ON order_details(order_id);

-- ============================================================
-- 6. TRIGGERS — keep inventory in sync with stock movements
-- ============================================================

DELIMITER //

CREATE TRIGGER trg_stock_in_apply
AFTER INSERT ON stock_in
FOR EACH ROW
BEGIN
    INSERT INTO inventory (product_id, warehouse_id, quantity)
    VALUES (NEW.product_id, NEW.warehouse_id, NEW.quantity)
    ON DUPLICATE KEY UPDATE quantity = quantity + NEW.quantity;
END//

CREATE TRIGGER trg_stock_out_apply
AFTER INSERT ON stock_out
FOR EACH ROW
BEGIN
    UPDATE inventory
    SET quantity = quantity - NEW.quantity
    WHERE product_id = NEW.product_id AND warehouse_id = NEW.warehouse_id;
END//

DELIMITER ;

-- ============================================================
-- 7. STORED PROCEDURES — safe entry points for stock movement
-- ============================================================

DELIMITER //

CREATE PROCEDURE sp_record_stock_in (
    IN p_product_id INT,
    IN p_warehouse_id INT,
    IN p_supplier_id INT,
    IN p_quantity INT
)
BEGIN
    INSERT INTO stock_in (product_id, warehouse_id, supplier_id, quantity)
    VALUES (p_product_id, p_warehouse_id, p_supplier_id, p_quantity);
END//

CREATE PROCEDURE sp_record_stock_out (
    IN p_product_id INT,
    IN p_warehouse_id INT,
    IN p_quantity INT,
    IN p_reference_type VARCHAR(50)
)
BEGIN
    DECLARE v_available INT DEFAULT 0;

    SELECT quantity INTO v_available
    FROM inventory
    WHERE product_id = p_product_id AND warehouse_id = p_warehouse_id;

    IF v_available IS NULL OR v_available < p_quantity THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not enough stock available for this stock-out';
    ELSE
        INSERT INTO stock_out (product_id, warehouse_id, quantity, reference_type)
        VALUES (p_product_id, p_warehouse_id, p_quantity, p_reference_type);
    END IF;
END//

DELIMITER ;

-- ============================================================
-- 8. VIEWS — matches the "Reports & Analytics" box in the diagram
-- ============================================================

-- Stock Summary: current quantity of every product, across all warehouses
CREATE VIEW vw_stock_summary AS
SELECT p.product_id, p.product_name, SUM(i.quantity) AS total_quantity
FROM products p
LEFT JOIN inventory i ON i.product_id = p.product_id
GROUP BY p.product_id, p.product_name;

-- Low Stock Report: products below their reorder level, per warehouse
CREATE VIEW vw_low_stock_report AS
SELECT p.product_name, w.warehouse_name, i.quantity, p.reorder_level
FROM inventory i
JOIN products p ON p.product_id = i.product_id
JOIN warehouses w ON w.warehouse_id = i.warehouse_id
WHERE i.quantity < p.reorder_level;

-- Warehouse-wise Stock: totals per warehouse
CREATE VIEW vw_warehouse_wise_stock AS
SELECT w.warehouse_id, w.warehouse_name,
       COUNT(i.product_id) AS distinct_products,
       SUM(i.quantity) AS total_units
FROM warehouses w
JOIN inventory i ON i.warehouse_id = w.warehouse_id
GROUP BY w.warehouse_id, w.warehouse_name;

-- Order Report: each order with customer name and item count
CREATE VIEW vw_order_report AS
SELECT o.order_id, c.customer_name, o.order_date, o.status,
       COUNT(od.order_detail_id) AS item_count, o.total_amount
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
LEFT JOIN order_details od ON od.order_id = o.order_id
GROUP BY o.order_id, c.customer_name, o.order_date, o.status, o.total_amount;

-- Sales Report: total quantity and revenue sold per product
CREATE VIEW vw_sales_report AS
SELECT p.product_id, p.product_name,
       SUM(od.quantity) AS total_units_sold,
       SUM(od.quantity * od.unit_price) AS total_revenue
FROM order_details od
JOIN products p ON p.product_id = od.product_id
GROUP BY p.product_id, p.product_name;

-- ============================================================
-- 9. Sample data
-- ============================================================

INSERT INTO users (name, username, password, role) VALUES
('Admin User', 'admin', '$2b$12$5EWESrzNBb0vzOipU5VpMem.90G9x5BGRdctyiOFX/8n4ZpxQXq3C', 'ADMIN'),
('Staff User', 'staff1', '$2b$12$replace_with_real_bcrypt_hash', 'STAFF');

INSERT INTO categories (category_name, description) VALUES
('Electronics', 'Consumer electronics and accessories'),
('Stationery', 'Office and school supplies'),
('Packaging', 'Boxes, tape, and shipping materials');

INSERT INTO suppliers (supplier_name, contact_no, email, address) VALUES
('BrightTech Distributors', '9876543210', 'sales@brighttech.com', 'Hyderabad, TS'),
('OfficePro Supplies', '9812345678', 'contact@officepro.com', 'Bengaluru, KA');

INSERT INTO warehouses (warehouse_name, location, address) VALUES
('Central Warehouse', 'Hyderabad', 'Plot 12, Industrial Area, Hyderabad'),
('South Depot', 'Bengaluru', 'Whitefield, Bengaluru');

INSERT INTO customers (customer_name, contact_no, email, address) VALUES
('Ravi Kumar', '9000011111', 'ravi.kumar@example.com', 'Hyderabad'),
('Ananya Rao', '9000022222', 'ananya.rao@example.com', 'Bengaluru');

INSERT INTO products (product_name, category_id, unit_price, reorder_level) VALUES
('Wireless Mouse', 1, 799.00, 20),
('USB-C Hub', 1, 1499.00, 15),
('A4 Notebook Pack', 2, 250.00, 30),
('Corrugated Box (Medium)', 3, 350.00, 25);

-- Stock arriving (trigger fills `inventory` automatically)
CALL sp_record_stock_in(1, 1, 1, 50);
CALL sp_record_stock_in(1, 2, 1, 30);
CALL sp_record_stock_in(2, 1, 1, 40);
CALL sp_record_stock_in(2, 2, 1, 10);
CALL sp_record_stock_in(3, 1, 2, 100);
CALL sp_record_stock_in(3, 2, 2, 60);
CALL sp_record_stock_in(4, 1, 2, 80);
CALL sp_record_stock_in(4, 2, 2, 40);

-- A sample order
INSERT INTO orders (customer_id, status) VALUES (1, 'CONFIRMED');
INSERT INTO order_details (order_id, product_id, quantity, unit_price) VALUES
(1, 1, 2, 799.00),
(1, 3, 5, 250.00);
UPDATE orders SET total_amount = (
    SELECT SUM(quantity * unit_price) FROM order_details WHERE order_id = 1
) WHERE order_id = 1;

-- Stock leaving because of that order
CALL sp_record_stock_out(1, 1, 2, 'ORDER');
CALL sp_record_stock_out(3, 1, 5, 'ORDER');

-- ============================================================
-- 10. Quick checks
-- ============================================================

SELECT * FROM vw_stock_summary;
SELECT * FROM vw_low_stock_report;
SELECT * FROM vw_warehouse_wise_stock;
SELECT * FROM vw_order_report;
SELECT * FROM vw_sales_report;
